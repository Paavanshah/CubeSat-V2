Virtual Wire

This is the VirtualWire library for Arduino
It provides a simple message passing protocol for a range of inexpensive
transmitter and receiver modules.

See http://www.open.com.au/mikem/arduino/VirtualWire.pdf for full documentation.

